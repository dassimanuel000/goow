import Vue from 'vue'
import Draggable from 'vuedraggable'

Vue.component('Draggable', Draggable)
