import Vue from 'vue'
import VueSlider from 'vue-range-component'

Vue.component('VueRangeSlider', VueSlider)
