import Vue from 'vue'
import Datepicker from 'vuejs-datepicker'

Vue.component('Datepicker', Datepicker)
