<template>
  <div class="footer">
    <div class="section__up">
      <nuxt-link :to="`/`" class="section__up-logo">
        <svg
          width="125"
          height="33"
          viewBox="0 0 125 33"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <g clip-path="url(#clip0)">
            <path
              d="M51.3835 0C42.5463 0 35.3486 7.40648 35.3486 16.5C35.3486 25.5935 42.5463 33 51.3835 33V0Z"
              fill="#FEB42B"
            />
            <path
              d="M51.1836 33C52.7075 33 53.9428 25.6127 53.9428 16.5C53.9428 7.3873 52.7075 0 51.1836 0C49.6598 0 48.4245 7.3873 48.4245 16.5C48.4245 25.6127 49.6598 33 51.1836 33Z"
              fill="#FB914E"
            />
            <path
              d="M67.5384 33C76.3755 33 83.5732 25.5935 83.5732 16.5C83.5732 7.40648 76.3755 0 67.5384 0V33Z"
              fill="#1EC173"
            />
            <path
              d="M67.7783 33C69.3021 33 70.5374 25.6127 70.5374 16.5C70.5374 7.3873 69.3021 0 67.7783 0C66.2545 0 65.0192 7.3873 65.0192 16.5C65.0192 25.6127 66.2545 33 67.7783 33Z"
              fill="#119352"
            />
            <path
              d="M56.6619 31.7244C58.1857 31.7244 59.421 24.9082 59.421 16.5C59.421 8.09173 58.1857 1.27551 56.6619 1.27551C55.1381 1.27551 53.9028 8.09173 53.9028 16.5C53.9028 24.9082 55.1381 31.7244 56.6619 31.7244Z"
              fill="#FF4583"
            />
            <path
              d="M62.1801 31.7244C63.7039 31.7244 64.9392 24.9082 64.9392 16.5C64.9392 8.09173 63.7039 1.27551 62.1801 1.27551C60.6563 1.27551 59.421 8.09173 59.421 16.5C59.421 24.9082 60.6563 31.7244 62.1801 31.7244Z"
              fill="#3B1099"
            />
            <path
              d="M31.6299 14.3604H27.0313V16.7469C27.0313 23.1247 21.993 28.3092 15.7949 28.3092C9.59693 28.3092 4.55854 23.1247 4.55854 16.7469C4.55854 10.3691 9.59693 5.18456 15.7949 5.18456C18.714 5.18456 21.5131 6.33668 23.5924 8.43518L25.2319 10.0811L28.4309 6.66585L26.7914 5.01997C23.8724 2.09852 19.9536 0.452637 15.8349 0.452637C7.07773 0.452637 0 7.77683 0 16.7469C0 25.717 7.07773 33.0412 15.8349 33.0412C24.5921 33.0412 31.6699 25.7581 31.6699 16.7469L31.6299 14.3604Z"
              fill="#565656"
            />
            <path
              d="M31.6298 13.8254H21.4331V18.5574H31.6298V13.8254Z"
              fill="#565656"
            />
            <path
              d="M120.721 1.06982L114.083 27.1571L107.126 1.06982H102.847L111.084 31.9302H117.122L125 1.06982H120.721Z"
              fill="#565656"
            />
            <path
              d="M102.687 1.06982L96.0492 27.1571L89.0915 1.06982H84.8128L93.0502 31.9302H99.0883L106.966 1.06982H102.687Z"
              fill="#565656"
            />
          </g>
          <defs>
            <clipPath id="clip0">
              <rect width="125" height="33" fill="white" />
            </clipPath>
          </defs>
        </svg>
      </nuxt-link>
      <div class="section__up-grid">
        <div class="section__up-paragraph">
          <div>
            <nuxt-link class="section__up-paragraph-title" :to="`/contact`"
              >Nous contacter</nuxt-link
            >
          </div>
          <div>
            <nuxt-link class="section__up-paragraph-title" :to="`/projects`"
              >Rejoignez-nous</nuxt-link
            >
          </div>
          <div>
            <nuxt-link
              class="section__up-paragraph-title"
              :to="`/i-am-merchant`"
              >Créer votre boutique</nuxt-link
            >
          </div>
        </div>
        <!-- <div class="section__up-paragraph">
          <div class="section__up-paragraph-title">COMMENT ÇA MARCHE</div>
          <div class="section__up-paragraph-link">S’inscrire</div>
          <div class="section__up-paragraph-link">Parrainage</div>
          <div class="section__up-paragraph-link">S’abonner</div>
          <div class="section__up-paragraph-link">Click and Collect</div>
        </div> -->
        <!-- <div class="section__up-paragraph">
          <div class="section__up-paragraph-title">MAIRIE</div>
          <div class="section__up-paragraph-link">Ce qu’il faut savoir</div>
          <div class="section__up-paragraph-link">Inscription</div>
          <div class="section__up-paragraph-link">Abonnement</div>
        </div> -->
        <!-- <div class="section__up-paragraph">
          <div class="section__up-paragraph-title">A PROPOS DE NOUS</div>
          <div class="section__up-paragraph-link">Qui sommes-nous ?</div>
          <div class="section__up-paragraph-link">Nos engagements</div>
          <div class="section__up-paragraph-link">Nos valeurs</div>
        </div> -->
      </div>
    </div>
    <div class="section__down">
      <div class="section__down-left">
        <!-- <div class="section__down-text">Mentions légales - Cookies - CGV</div> -->
        <div class="section__down-text">Hello@goow.fr</div>
        <div class="section__down-text">GOOW©2021</div>
      </div>
      <div class="section__down-right reseau">
        <a href="https://www.instagram.com/_goow_">
          <img class="reseau__img" src="/icons/insta.png" />
        </a>
        <a href="https://www.linkedin.com/company/goowfr/">
          <img class="reseau__img" src="/icons/linkdin.png" />
        </a>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Footer',
}
</script>

<style lang="scss" scoped>
.reseau {
  &__img {
    height: 60px;
    width: 60px;
  }
}
.footer {
  width: 100%;
  background: rgba(196, 196, 196, 0.2);
  padding: 72px 87px 74px 34px;
}
.section {
  &__up {
    display: flex;
    justify-content: space-between;
    &-logo {
      width: 320px;
      display: inline;
    }
    &-grid {
      width: 100%;
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
      align-items: start;
    }
    &-paragraph {
      &-title {
        font-family: Open Sans, serif;
        font-style: normal;
        font-weight: bold;
        font-size: 16px;
        line-height: 22px;
        letter-spacing: 0.05em;
        color: #565656;
        margin-bottom: 33px;
        text-decoration: none;
      }
      &-link {
        cursor: pointer;
        color: rgba(154, 154, 154, 0.46);
        font-family: Open Sans, serif;
        margin-bottom: 25px;
        font-style: normal;
        font-size: 16px;
      }
    }
  }
  &__down {
    margin-top: 143px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    &-left {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 417px;
    }
    &-text {
      font-family: Open Sans;
      font-style: normal;
      font-weight: normal;
      font-size: 16px;
      color: #c4c4c4;
    }
  }
}
@media screen and (max-width: 1024px) {
  .section {
    &__up {
      display: block;
      margin: 0 auto;
      &-logo {
        width: 100px;
        display: block;
        margin: 0 auto 50px auto;
      }
      &-grid {
        width: 100%;
        text-align: center;
      }
      &-paragraph {
        width: 50%;
        margin-bottom: 50px;
      }
    }
    &__down {
      margin-top: 50px;
      flex-wrap: wrap;
    }
  }
}
@media screen and (max-width: 815px) {
  .footer {
    padding: 72px 0 0 0;
  }
  .section {
    &__up {
      &-logo {
        width: 125px;
      }
      &-paragraph {
        width: 100%;
        margin-bottom: 50px;
      }
    }
    &__down {
      margin-top: 50px;
      &-text {
        width: 100%;
        text-align: center;
      }
      &-left {
        width: 100%;
        display: block;
        margin-bottom: 50px;
        text-align: center;
      }
      &-right {
        width: 100%;
        margin-bottom: 50px;
        svg {
          display: block;
          margin: 0 auto;
        }
      }
    }
  }
}
</style>
