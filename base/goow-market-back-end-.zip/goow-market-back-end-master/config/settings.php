<?php
return [
    'front_url' => env('FRONT_URL')
];
